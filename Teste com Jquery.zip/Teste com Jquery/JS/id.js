$(document).ready(function(){

    $().click(function(){
        
    })
})